@org.junit.Test
public void ${NAME}() {
  ${BODY}
  
  // given
  
  // when
  
  // then
}