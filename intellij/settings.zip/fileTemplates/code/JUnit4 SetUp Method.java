@org.junit.Before
public void setup() {
  ${BODY}
}